import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HobbiComponent } from './hobbi.component';

describe('HobbiComponent', () => {
  let component: HobbiComponent;
  let fixture: ComponentFixture<HobbiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HobbiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HobbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
