import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hobbi',
  templateUrl: './hobbi.component.html',
  styleUrls: ['./hobbi.component.css']
})
export class HobbiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
