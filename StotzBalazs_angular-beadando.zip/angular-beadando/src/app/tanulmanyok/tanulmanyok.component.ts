import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tanulmanyok',
  templateUrl: './tanulmanyok.component.html',
  styleUrls: ['./tanulmanyok.component.css']
})
export class TanulmanyokComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
