import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TanulmanyokComponent } from './tanulmanyok.component';

describe('TanulmanyokComponent', () => {
  let component: TanulmanyokComponent;
  let fixture: ComponentFixture<TanulmanyokComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TanulmanyokComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TanulmanyokComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
