import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tapasztalat',
  templateUrl: './tapasztalat.component.html',
  styleUrls: ['./tapasztalat.component.css']
})
export class TapasztalatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
