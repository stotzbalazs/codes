import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TapasztalatComponent } from './tapasztalat.component';

describe('TapasztalatComponent', () => {
  let component: TapasztalatComponent;
  let fixture: ComponentFixture<TapasztalatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TapasztalatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TapasztalatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
